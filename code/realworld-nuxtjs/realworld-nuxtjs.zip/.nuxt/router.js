import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1cabcc7b = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _74f7e670 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _2a3d2ff8 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _68d7e278 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _43647d34 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _10dcf2be = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _4fa225c5 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _1cabcc7b,
    children: [{
      path: "",
      component: _74f7e670,
      name: "home"
    }, {
      path: "/login",
      component: _2a3d2ff8,
      name: "login"
    }, {
      path: "/register",
      component: _2a3d2ff8,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _68d7e278,
      name: "profile"
    }, {
      path: "/settings/",
      component: _43647d34,
      name: "settings"
    }, {
      path: "/editor/",
      component: _10dcf2be,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _4fa225c5,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
